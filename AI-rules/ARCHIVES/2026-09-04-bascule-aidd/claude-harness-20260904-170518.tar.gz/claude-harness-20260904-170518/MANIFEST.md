# Sauvegarde du harnais dev-with-ai

Prise avant bascule complète sous AIDD.

## Contenu

- `claude/settings.json` — settings.json global vécu, AVANT retrait des hooks du harnais.
  Contient aussi vibe-island, statusline, thème, permissions : ce n'est pas que le harnais.
- `claude/settings.json.bak-*`, `claude/settings.local.json*` — variantes déjà présentes.
- `claude/{CLAUDE.md,commands,agents,hooks}` — contenu RÉSOLU des symlinks
  (l'original vit dans le dépôt `dev-with-ai/AI-rules/`, ceci est une copie autonome).
- `codex/AGENTS.md`, `codex/skills/` — les 18 skills Codex générés par install.sh.
- `repo/uncommitted.patch` + `repo/untracked/` — le travail non committé du dépôt
  au moment de la sauvegarde (`repo/HEAD.txt` donne le commit de base).
- `symlinks-avant.txt` — la carte des liens telle qu'elle était.

Rien de `~/.codex/auth.json` ni d'aucun fichier porteur de secret n'a été copié.

## Ce qui a été retiré ensuite

1. Symlinks : `~/.claude/{CLAUDE.md,commands,agents,hooks}`, `~/.codex/AGENTS.md`
2. Les 18 skills sous `~/.codex/skills/` portant le marqueur
   `<!-- managed by dev-with-ai/AI-rules/install.sh -->`
3. Dans `~/.claude/settings.json` : les deux déclarations de hooks du harnais
   (`scope-guard.sh` en PreToolUse, `session-start.sh` en SessionStart).
   Tout le reste — vibe-island, statusline, thème, permissions — est intact.
4. Les anciennes copies `~/.claude/settings.json.bak-*` et `.avant-*` (archivées ici).

Le dépôt `~/dev/dev-with-ai` n'a pas été touché.

## Restauration

Intégrale, en une commande :

    ~/dev/dev-with-ai/AI-rules/install.sh

install.sh est idempotent : il repose les symlinks, régénère les skills Codex,
et signale les déclarations de hooks à réintroduire à la main dans settings.json
(il n'y écrit jamais).

Restauration du seul settings.json global :

    cp claude/settings.json ~/.claude/settings.json

Réapplication du travail non committé :

    cd ~/dev/dev-with-ai && git apply <cette-sauvegarde>/repo/uncommitted.patch
